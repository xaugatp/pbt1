﻿#dimension of the board
dimensions=(10,10)

‌